﻿namespace Project13
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTeamName = new System.Windows.Forms.Label();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.txtTeamDivision = new System.Windows.Forms.TextBox();
            this.lblTeamDivision = new System.Windows.Forms.Label();
            this.txtNumWins = new System.Windows.Forms.TextBox();
            this.lblNumWins = new System.Windows.Forms.Label();
            this.txtNumLosses = new System.Windows.Forms.TextBox();
            this.lblNumLosses = new System.Windows.Forms.Label();
            this.txtNumTies = new System.Windows.Forms.TextBox();
            this.lblNumTies = new System.Windows.Forms.Label();
            this.txtNumGames = new System.Windows.Forms.TextBox();
            this.lblNumGames = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lstTeams = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblTeamName
            // 
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Location = new System.Drawing.Point(31, 24);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(85, 17);
            this.lblTeamName.TabIndex = 0;
            this.lblTeamName.Text = "Team Name";
            // 
            // txtTeamName
            // 
            this.txtTeamName.Location = new System.Drawing.Point(24, 44);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.ReadOnly = true;
            this.txtTeamName.Size = new System.Drawing.Size(100, 22);
            this.txtTeamName.TabIndex = 1;
            // 
            // txtTeamDivision
            // 
            this.txtTeamDivision.Location = new System.Drawing.Point(143, 44);
            this.txtTeamDivision.Name = "txtTeamDivision";
            this.txtTeamDivision.ReadOnly = true;
            this.txtTeamDivision.Size = new System.Drawing.Size(100, 22);
            this.txtTeamDivision.TabIndex = 3;
            // 
            // lblTeamDivision
            // 
            this.lblTeamDivision.AutoSize = true;
            this.lblTeamDivision.Location = new System.Drawing.Point(144, 24);
            this.lblTeamDivision.Name = "lblTeamDivision";
            this.lblTeamDivision.Size = new System.Drawing.Size(97, 17);
            this.lblTeamDivision.TabIndex = 2;
            this.lblTeamDivision.Text = "Team Division";
            // 
            // txtNumWins
            // 
            this.txtNumWins.Location = new System.Drawing.Point(24, 102);
            this.txtNumWins.Name = "txtNumWins";
            this.txtNumWins.ReadOnly = true;
            this.txtNumWins.Size = new System.Drawing.Size(100, 22);
            this.txtNumWins.TabIndex = 5;
            // 
            // lblNumWins
            // 
            this.lblNumWins.AutoSize = true;
            this.lblNumWins.Location = new System.Drawing.Point(20, 82);
            this.lblNumWins.Name = "lblNumWins";
            this.lblNumWins.Size = new System.Drawing.Size(109, 17);
            this.lblNumWins.TabIndex = 4;
            this.lblNumWins.Text = "Number of Wins";
            // 
            // txtNumLosses
            // 
            this.txtNumLosses.Location = new System.Drawing.Point(144, 102);
            this.txtNumLosses.Name = "txtNumLosses";
            this.txtNumLosses.ReadOnly = true;
            this.txtNumLosses.Size = new System.Drawing.Size(100, 22);
            this.txtNumLosses.TabIndex = 7;
            // 
            // lblNumLosses
            // 
            this.lblNumLosses.AutoSize = true;
            this.lblNumLosses.Location = new System.Drawing.Point(136, 82);
            this.lblNumLosses.Name = "lblNumLosses";
            this.lblNumLosses.Size = new System.Drawing.Size(123, 17);
            this.lblNumLosses.TabIndex = 6;
            this.lblNumLosses.Text = "Number of Losses";
            // 
            // txtNumTies
            // 
            this.txtNumTies.Location = new System.Drawing.Point(24, 159);
            this.txtNumTies.Name = "txtNumTies";
            this.txtNumTies.ReadOnly = true;
            this.txtNumTies.Size = new System.Drawing.Size(100, 22);
            this.txtNumTies.TabIndex = 9;
            // 
            // lblNumTies
            // 
            this.lblNumTies.AutoSize = true;
            this.lblNumTies.Location = new System.Drawing.Point(20, 139);
            this.lblNumTies.Name = "lblNumTies";
            this.lblNumTies.Size = new System.Drawing.Size(105, 17);
            this.lblNumTies.TabIndex = 8;
            this.lblNumTies.Text = "Number of Ties";
            // 
            // txtNumGames
            // 
            this.txtNumGames.Location = new System.Drawing.Point(145, 159);
            this.txtNumGames.Name = "txtNumGames";
            this.txtNumGames.ReadOnly = true;
            this.txtNumGames.Size = new System.Drawing.Size(100, 22);
            this.txtNumGames.TabIndex = 11;
            // 
            // lblNumGames
            // 
            this.lblNumGames.AutoSize = true;
            this.lblNumGames.Location = new System.Drawing.Point(126, 139);
            this.lblNumGames.Name = "lblNumGames";
            this.lblNumGames.Size = new System.Drawing.Size(136, 17);
            this.lblNumGames.TabIndex = 10;
            this.lblNumGames.Text = "Total Games Played";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(28, 204);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(97, 34);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(28, 244);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(97, 34);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Location = new System.Drawing.Point(143, 204);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(97, 34);
            this.btnEdit.TabIndex = 14;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(143, 244);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(97, 34);
            this.btnDelete.TabIndex = 15;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lstTeams
            // 
            this.lstTeams.FormattingEnabled = true;
            this.lstTeams.ItemHeight = 16;
            this.lstTeams.Location = new System.Drawing.Point(283, 24);
            this.lstTeams.Name = "lstTeams";
            this.lstTeams.Size = new System.Drawing.Size(120, 260);
            this.lstTeams.TabIndex = 16;
            this.lstTeams.SelectedIndexChanged += new System.EventHandler(this.lstTeams_SelectedIndexChanged);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 308);
            this.Controls.Add(this.lstTeams);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtNumGames);
            this.Controls.Add(this.lblNumGames);
            this.Controls.Add(this.txtNumTies);
            this.Controls.Add(this.lblNumTies);
            this.Controls.Add(this.txtNumLosses);
            this.Controls.Add(this.lblNumLosses);
            this.Controls.Add(this.txtNumWins);
            this.Controls.Add(this.lblNumWins);
            this.Controls.Add(this.txtTeamDivision);
            this.Controls.Add(this.lblTeamDivision);
            this.Controls.Add(this.txtTeamName);
            this.Controls.Add(this.lblTeamName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Team Score Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.TextBox txtTeamDivision;
        private System.Windows.Forms.Label lblTeamDivision;
        private System.Windows.Forms.TextBox txtNumWins;
        private System.Windows.Forms.Label lblNumWins;
        private System.Windows.Forms.TextBox txtNumLosses;
        private System.Windows.Forms.Label lblNumLosses;
        private System.Windows.Forms.TextBox txtNumTies;
        private System.Windows.Forms.Label lblNumTies;
        private System.Windows.Forms.TextBox txtNumGames;
        private System.Windows.Forms.Label lblNumGames;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ListBox lstTeams;
    }
}


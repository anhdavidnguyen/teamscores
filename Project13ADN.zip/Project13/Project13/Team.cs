﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project13
{
    [Serializable]
    public class Team
    {
        private string name;
        private string division;
        private int wins;
        private int losses;
        private int ties;
        
        /// <summary>
        /// Return te total number of games
        /// </summary>
        public int CalculateTotalGames()
        {
            return wins + losses + ties;
        }

        /// <summary>
        /// Return a string representation of a team
        /// </summary>
        public override string ToString()
        {
            return name;
        }

        /// <summary>
        /// Setter/egger for the ties property
        /// </summary>
        public int Ties
        {
            get
            {
                return ties;
            }
            set
            {
                if (value < 0)
                    throw new Exception("Invalid ties value.");

                ties = value;
            }
        }

        /// <summary>
        /// Setter/getter for the losses property
        /// </summary>
        public int Losses
        {
            get
            {
                return losses;
            }
            set
            {
                if (value < 0)
                    throw new Exception("Invalid losses value.");

                losses = value;
            }
        }

        /// <summary>
        /// Setter/getter for the wins property
        /// </summary>
        public int Wins
        {
            get
            {
                return wins;
            }
            set
            {
                if (value < 0)
                    throw new Exception("Invalid wins value.");

                wins = value;
            }
        }

        /// <summary>
        /// Setter/getter for the division property
        /// </summary>
        public string Division
        {
            get
            {
                return division;
            }
            set
            {
                division = value;
            }
        }

        /// <summary>
        /// Setter/Getter for the name property
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }
}

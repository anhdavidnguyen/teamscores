﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project13
{
    public partial class FrmAddEditTeam : Form
    {
        private Team team;

        /// <summary>
        /// Initialize UI
        /// </summary>
        public FrmAddEditTeam()
        {
            InitializeComponent();
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        /// <summary>
        /// Setter and getter to the team property
        /// </summary>
        public Team CreatedOrUpdatedTeam
        {
            get
            {
                return team;
            }
            set
            {
                team = value;

                txtTeamName.Text = team.Name;
                txtTeamDivision.Text = team.Division;
                txtNumWins.Text = team.Wins.ToString();
                txtNumTies.Text = team.Ties.ToString();
                txtNumLosses.Text = team.Losses.ToString();
            }
        }

        /// <summary>
        /// Close the window
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Create a new team
        /// </summary>
        private void btnOk_Click(object sender, EventArgs e)
        {
            // Either perform an update or create a new team
            string name = txtTeamName.Text.Trim();
            string division = txtTeamDivision.Text.Trim();
            string strWins = txtNumWins.Text.Trim();
            string strLosses = txtNumLosses.Text.Trim();
            string strTies = txtNumTies.Text.Trim();

            if(name == string.Empty || division == string.Empty || strWins == string.Empty || strLosses == string.Empty || strTies == string.Empty)
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            int wins, losses, ties;

            if(!int.TryParse(strWins, out wins) || !int.TryParse(strLosses, out losses) || !int.TryParse(strTies, out ties))
            {
                MessageBox.Show("The wins, ties, and/or losses should be integer values.");
                return;
            }

            // Create or update the team
            try
            {
                if(team == null)
                    team = new Team();

                team.Name = name;
                team.Division = division;
                team.Wins = wins;
                team.Losses = losses;
                team.Ties = ties;

                DialogResult = System.Windows.Forms.DialogResult.OK;
                Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

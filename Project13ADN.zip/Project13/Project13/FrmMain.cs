﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project13
{
    public partial class FrmMain : Form
    {
        /// <summary>
        /// Initialize UI
        /// </summary>
        public FrmMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Load the teams from file
        /// </summary>
        private void FrmMain_Load(object sender, EventArgs e)
        {
            try
            {
                Stream stream = File.Open("Teams.dat", FileMode.Open);
                BinaryFormatter formatter = new BinaryFormatter();
                List<Team> teams = formatter.Deserialize(stream) as List<Team>;
                stream.Close();

                foreach (Team team in teams)
                    lstTeams.Items.Add(team);
            }
            catch { }
        }

        /// <summary>
        /// Terminates the application
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Show window for creating a new team
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            FrmAddEditTeam window = new FrmAddEditTeam();

            if(window.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // Add the new team
                lstTeams.Items.Add(window.CreatedOrUpdatedTeam);
            }
        }

        /// <summary>
        /// Load team info to UI
        /// </summary>
        private void lstTeams_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstTeams.SelectedIndex == -1)
            {
                // Clear fields if no team selected
                txtTeamName.Clear();
                txtTeamDivision.Clear();
                txtNumGames.Clear();
                txtNumLosses.Clear();
                txtNumTies.Clear();
                txtNumWins.Clear();

                btnEdit.Enabled = false;
                btnDelete.Enabled = false;

                return;
            }

            // Load the team info
            Team team = lstTeams.SelectedItem as Team;
            txtTeamName.Text = team.Name;
            txtTeamDivision.Text = team.Division;
            txtNumWins.Text = team.Wins.ToString();
            txtNumLosses.Text = team.Losses.ToString();
            txtNumTies.Text = team.Ties.ToString();
            txtNumGames.Text = team.CalculateTotalGames().ToString();

            btnEdit.Enabled = true;
            btnDelete.Enabled = true;
        }

        /// <summary>
        /// Show the window for editing a team
        /// </summary>
        private void btnEdit_Click(object sender, EventArgs e)
        {
            FrmAddEditTeam window = new FrmAddEditTeam();
            window.CreatedOrUpdatedTeam = lstTeams.SelectedItem as Team;

            if(window.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                lstTeams.Items[lstTeams.SelectedIndex] = lstTeams.Items[lstTeams.SelectedIndex];
        }

        /// <summary>
        /// Delete a team
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Team team = lstTeams.SelectedItem as Team;

            if(MessageBox.Show("Are you sure you want to delete " + team.Name + "?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                // Remove team upon confirmation
                lstTeams.Items.Remove(team);
            }
        }

        /// <summary>
        /// Save the teams to file
        /// </summary>
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                List<Team> teams = new List<Team>();

                foreach (Object obj in lstTeams.Items)
                    teams.Add(obj as Team);

                Stream stream = File.Open("Teams.dat", FileMode.Create);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, teams);
                stream.Close();

                MessageBox.Show("All saved!", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch { }
        }
    }
}

/* AnhDavid Nguyen  4.17.2018
What concepts did you find challenging about this program? (Please be specific) 
It took me awhile to figure out how to update the listbox when an item inside it gets updated.
 
What did you learn in this program? (Please be specific) 
I learned the usefulness of serialization where you can save and load an object to and from file.
*/
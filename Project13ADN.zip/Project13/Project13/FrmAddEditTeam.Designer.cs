﻿namespace Project13
{
    partial class FrmAddEditTeam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumTies = new System.Windows.Forms.TextBox();
            this.lblNumTies = new System.Windows.Forms.Label();
            this.txtNumLosses = new System.Windows.Forms.TextBox();
            this.lblNumLosses = new System.Windows.Forms.Label();
            this.txtNumWins = new System.Windows.Forms.TextBox();
            this.lblNumWins = new System.Windows.Forms.Label();
            this.txtTeamDivision = new System.Windows.Forms.TextBox();
            this.lblTeamDivision = new System.Windows.Forms.Label();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNumTies
            // 
            this.txtNumTies.Location = new System.Drawing.Point(84, 263);
            this.txtNumTies.Name = "txtNumTies";
            this.txtNumTies.Size = new System.Drawing.Size(100, 22);
            this.txtNumTies.TabIndex = 5;
            // 
            // lblNumTies
            // 
            this.lblNumTies.AutoSize = true;
            this.lblNumTies.Location = new System.Drawing.Point(80, 243);
            this.lblNumTies.Name = "lblNumTies";
            this.lblNumTies.Size = new System.Drawing.Size(105, 17);
            this.lblNumTies.TabIndex = 20;
            this.lblNumTies.Text = "Number of Ties";
            // 
            // txtNumLosses
            // 
            this.txtNumLosses.Location = new System.Drawing.Point(84, 152);
            this.txtNumLosses.Name = "txtNumLosses";
            this.txtNumLosses.Size = new System.Drawing.Size(100, 22);
            this.txtNumLosses.TabIndex = 3;
            // 
            // lblNumLosses
            // 
            this.lblNumLosses.AutoSize = true;
            this.lblNumLosses.Location = new System.Drawing.Point(76, 132);
            this.lblNumLosses.Name = "lblNumLosses";
            this.lblNumLosses.Size = new System.Drawing.Size(123, 17);
            this.lblNumLosses.TabIndex = 18;
            this.lblNumLosses.Text = "Number of Losses";
            // 
            // txtNumWins
            // 
            this.txtNumWins.Location = new System.Drawing.Point(84, 206);
            this.txtNumWins.Name = "txtNumWins";
            this.txtNumWins.Size = new System.Drawing.Size(100, 22);
            this.txtNumWins.TabIndex = 4;
            // 
            // lblNumWins
            // 
            this.lblNumWins.AutoSize = true;
            this.lblNumWins.Location = new System.Drawing.Point(80, 186);
            this.lblNumWins.Name = "lblNumWins";
            this.lblNumWins.Size = new System.Drawing.Size(109, 17);
            this.lblNumWins.TabIndex = 16;
            this.lblNumWins.Text = "Number of Wins";
            // 
            // txtTeamDivision
            // 
            this.txtTeamDivision.Location = new System.Drawing.Point(83, 94);
            this.txtTeamDivision.Name = "txtTeamDivision";
            this.txtTeamDivision.Size = new System.Drawing.Size(100, 22);
            this.txtTeamDivision.TabIndex = 2;
            // 
            // lblTeamDivision
            // 
            this.lblTeamDivision.AutoSize = true;
            this.lblTeamDivision.Location = new System.Drawing.Point(84, 74);
            this.lblTeamDivision.Name = "lblTeamDivision";
            this.lblTeamDivision.Size = new System.Drawing.Size(97, 17);
            this.lblTeamDivision.TabIndex = 14;
            this.lblTeamDivision.Text = "Team Division";
            // 
            // txtTeamName
            // 
            this.txtTeamName.Location = new System.Drawing.Point(82, 44);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(100, 22);
            this.txtTeamName.TabIndex = 1;
            // 
            // lblTeamName
            // 
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Location = new System.Drawing.Point(89, 24);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(85, 17);
            this.lblTeamName.TabIndex = 12;
            this.lblTeamName.Text = "Team Name";
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(151, 293);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(93, 36);
            this.btnOk.TabIndex = 6;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(33, 293);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(93, 36);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // FrmAddEditTeam
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(273, 338);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtNumTies);
            this.Controls.Add(this.lblNumTies);
            this.Controls.Add(this.txtNumLosses);
            this.Controls.Add(this.lblNumLosses);
            this.Controls.Add(this.txtNumWins);
            this.Controls.Add(this.lblNumWins);
            this.Controls.Add(this.txtTeamDivision);
            this.Controls.Add(this.lblTeamDivision);
            this.Controls.Add(this.txtTeamName);
            this.Controls.Add(this.lblTeamName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmAddEditTeam";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Team Add Edit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumTies;
        private System.Windows.Forms.Label lblNumTies;
        private System.Windows.Forms.TextBox txtNumLosses;
        private System.Windows.Forms.Label lblNumLosses;
        private System.Windows.Forms.TextBox txtNumWins;
        private System.Windows.Forms.Label lblNumWins;
        private System.Windows.Forms.TextBox txtTeamDivision;
        private System.Windows.Forms.Label lblTeamDivision;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
    }
}